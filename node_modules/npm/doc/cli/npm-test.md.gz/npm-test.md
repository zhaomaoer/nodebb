npm-test(1) -- Test a package
=============================

## SYNOPSIS

      npm test [-- <args>]
      npm tst [-- <args>]

## DESCRIPTION

This runs a package's "test" script, if one was provided.

To run tests as a condition of installation, set the `npat` config to
true.

## SEE ALSO

* npm-run-script(1)
* npm-scripts(7)
* npm-start(1)
* npm-restart(1)
* npm-stop(1)
