module.exports = require("./utils/lifecycle.js").cmd("start")
