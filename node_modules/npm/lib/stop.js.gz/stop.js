module.exports = require("./utils/lifecycle.js").cmd("stop")
