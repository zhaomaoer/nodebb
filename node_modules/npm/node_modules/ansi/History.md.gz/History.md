
0.3.0 / 2014-05-09
==================

  * package: remove "test" script and "devDependencies"
  * package: remove "engines" section
  * pacakge: remove "bin" section
  * package: beautify
  * examples: remove `starwars` example (#15)
  * Documented goto, horizontalAbsolute, and eraseLine methods in README.md (#12, @Jammerwoch)
  * add `.jshintrc` file

< 0.3.0
=======

  * Prehistoric
