Like `chmod -R`.

Takes the same arguments as `fs.chmod()`
