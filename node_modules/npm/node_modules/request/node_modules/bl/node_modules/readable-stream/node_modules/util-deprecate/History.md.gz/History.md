
1.0.1 / 2014-11-25
==================

  * browser: use `console.warn()` for deprecation calls
  * browser: more jsdocs

1.0.0 / 2014-04-30
==================

  * initial commit
